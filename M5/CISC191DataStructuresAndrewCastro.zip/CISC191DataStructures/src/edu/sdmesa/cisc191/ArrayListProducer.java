package edu.sdmesa.cisc191;
/**
 * Lead Author(s):
 * 
 * @author
 * @author
 *         <<add additional lead authors here, with a full first and last name>>
 * 
 * Other contributors:
 *         <<add additional contributors (mentors, tutors, friends) here, with
 *         contact information>>
 * 
 * References:
 *         Morelli, R., & Walde, R. (2016). Java, Java, Java: Object-Oriented Problem Solving.
 *         Retrieved from
 *         https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 * 
 *         <<add more references here>>
 * 
 * Version/date:
 * 
 * Responsibilities of class:
 * 
 */
import java.util.ArrayList;

public class ArrayListProducer
{
	//ArrayListProducer HAS-A ArrayList of strings
	private ArrayList<String> list;
	
	//Constructor for ArrayListProducer
	public ArrayListProducer(ArrayList<String> list)
	{
		this.list = list;
	}
	
	//Adds string to list to given index
	public void produce(int i, String string)
	{
		//Adds string to index i
		list.add(i, string);
	}

}

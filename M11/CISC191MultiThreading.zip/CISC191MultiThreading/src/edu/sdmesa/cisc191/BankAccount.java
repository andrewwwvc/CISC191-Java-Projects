package edu.sdmesa.cisc191;

/**
 * @author Allan Schougaard
 * @otherContributors: None
 * @version 1
 * @see Morelli, R., & Walde, R. (2016). Java, Java, Java: Object-Oriented
 *      Problem Solving.
 *      https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 * @see Bechtold, S., Brannen, S., Link, J., Merdes, M., Philipp, M., Rancourt,
 *      J. D., & Stein, C. (n.d.). JUnit 5 user guide. JUnit 5.
 *      https://junit.org/junit5/docs/current/user-guide/
 */

// TODO: comment the code

/**
 * 
 *
 */
public class BankAccount
{
	/**
	 *  BankAccount HAS-A balance
	 */
	private double balance = 0;
	
	/**
	 * deposits amount to bank account
	 * @param amount
	 */
	public synchronized void deposit(double amount)
	{
		balance += amount;
	}
	
	/**
	 * withdraws amount from bank account
	 * @param amount
	 */
	public synchronized void withdraw(double amount)
	{
		balance -= amount;
	}
	
	/**
	 * 
	 * @return balance
	 */
	public double getBalance()
	{
		return balance;
	}
}

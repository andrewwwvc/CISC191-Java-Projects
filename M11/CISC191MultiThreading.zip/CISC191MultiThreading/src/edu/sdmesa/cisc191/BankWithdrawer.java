package edu.sdmesa.cisc191;

/**
 * @author Allan Schougaard
 * @otherContributors: None
 * @version 1
 * @see Morelli, R., & Walde, R. (2016). Java, Java, Java: Object-Oriented
 *      Problem Solving.
 *      https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 * @see Bechtold, S., Brannen, S., Link, J., Merdes, M., Philipp, M., Rancourt,
 *      J. D., & Stein, C. (n.d.). JUnit 5 user guide. JUnit 5.
 *      https://junit.org/junit5/docs/current/user-guide/
 */


//BankWithdrawer IS-A Thread
public class BankWithdrawer extends Thread
{
	//BankWithdrawer HAS-A account
	private BankAccount account;
	//BankWithdrawer HAS-A total amount to withdraw
	private double totalAmountToWithdraw;

	//BankWithdrawer Constructor
	public BankWithdrawer(BankAccount givenAccount, double givenAmountToWithdraw)
	{
		account = givenAccount;
		totalAmountToWithdraw = givenAmountToWithdraw;
	}

	@Override
	public void run()
	{
		System.out.println(Thread.currentThread().getName() + " running...");
		
		//Can access one account at a time then moves to the next thread
		synchronized(account)
		{
			for (int counter = 0; counter < totalAmountToWithdraw; counter++)
			{
				// Withdraw $1 at a time
				account.withdraw(1);
			}
			
			System.out.println(Thread.currentThread().getName() + " end.");
		}

	}
}

package edu.sdmesa.cisc191;

/**
 * Lead Author(s):
 * 
 * @author
 * @author
 *         <<add additional lead authors here, with a full first and last name>>
 * 
 * Other contributors:
 *         <<add additional contributors (mentors, tutors, friends) here, with
 *         contact information>>
 * 
 * References:
 *         Morelli, R., & Walde, R. (2016). Java, Java, Java: Object-Oriented Problem Solving.
 *         Retrieved from
 *         https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 * 
 *         <<add more references here>>
 * 
 * Version/date:
 * 
 * Responsibilities of class:
 * 
 */

//TODO: comment the code

//Consumer IS-A Thread
public class Consumer extends Thread
{
	//Consumer HAS-A name
	private String name;
	//Consumer HAS-A warehouse
	private Warehouse warehouse;
	//Consumer HAS-A number of items to consume
	private int numberOfItemsToConsume;

	//Consumer Constructor
	public Consumer(String givenName, Warehouse givenWarehouse, int givenNumberOfItemsToConsume)
	{
		name = givenName;
		warehouse = givenWarehouse;
		numberOfItemsToConsume = givenNumberOfItemsToConsume;
	}

	@Override
	public void run()
	{
		System.out.println(name + " running in Thread: " + Thread.currentThread().getName());

		while(this.numberOfItemsToConsume > 0)
		{
			try 
			{
				warehouse.ship();
				//Decrements if ship was successful, otherwise throw exception
				this.numberOfItemsToConsume--;
			} 
			catch (OutOfStockException e) 
			{
				e.printStackTrace();
			}
			
		}

		System.out.println(name + " ended.");
	}

}

package edu.sdmesa.cisc191;

/**
 * Lead Author(s):
 * 
 * @author Andrew Castro
 * @author
 *         <<add additional lead authors here, with a full first and last name>>
 * 
 * Other contributors:
 *         <<add additional contributors (mentors, tutors, friends) here, with
 *         contact information>>
 * 
 * References:
 *         Morelli, R., & Walde, R. (2016). Java, Java, Java: Object-Oriented Problem Solving.
 *         Retrieved from
 *         https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 * 
 *         <<add more references here>>
 * 
 * Version/date:
 * 
 * Responsibilities of class:
 * An engine is an independent thread
 * An engine has a fuel level
 * An engine tracks its use of fuel when it runs, using one unit per second
 * An engine stops when it runs out of fuel
 */

//Engine is-a thread
public class Engine extends Thread
{
	//Engine HAS-A fuel level
	private int fuelLevel;
	
	//Default Engine Constructor
	public Engine()
	{
		fuelLevel = 0;
	}
	
	/*
	 * Setter method to set engine's fuel level
	 * @param int fuel level
	 */
	public void setFuelLevel(int fuelLevel)
	{
		this.fuelLevel = fuelLevel;
	}
	
	/*
	 * Getter method to get engine's fuel level
	 */
	public int getFuelLevel()
	{
		return fuelLevel;
	}
	
	public void run()
	{
		while(fuelLevel != 0)
		{
			try
			{
				//units in ms; 1000 = 1 sec
				sleep(1000);
			}
			catch (InterruptedException e)
			{
			}
			//Uses 1 unit of fuel level per second
			fuelLevel--;
		}
	}
	
	
}

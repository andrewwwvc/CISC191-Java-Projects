package edu.sdmesa.cisc191;

import java.util.ArrayList;
import java.util.LinkedList;

/**
 * Lead Author(s):
 * 
 * @author
 * @author
 *         <<add additional lead authors here, with a full first and last name>>
 * 
 * Other contributors:
 *         <<add additional contributors (mentors, tutors, friends) here, with
 *         contact information>>
 * 
 * References:
 *         Morelli, R., & Walde, R. (2016). Java, Java, Java: Object-Oriented Problem Solving.
 *         Retrieved from
 *         https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 * 
 *         <<add more references here>>
 * 
 * Version/date:
 * 
 * Responsibilities of class: A Warehouse receives, stores and ships Items.
 * 
 */
public class Warehouse 
{
	/**
	 * storage is managed as one big stack, where items are laid on top of each other
	 */
	private ArrayList<Item> storage = new ArrayList<Item>();

	public int getNumberOfItemsInStock()
	{
		return storage.size();
	}

	/**
	 * 
	 * @param item the item to store in the Warehouse
	 */
	public synchronized void receive(Item item)
	{
		storage.add(item);
	}

	/**
	 * 
	 * @return the item that was retrieved from storage
	 * @throws OutOfStockException if there are no items to ship
	 */
	public synchronized Item ship() throws OutOfStockException
	{
		// if there are any items in storage
		if(storage.size() == 0)
		{
			throw new OutOfStockException();
		}
		
		return storage.remove(storage.size()- 1);
	}
}
